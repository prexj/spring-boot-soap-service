package com.example.howtodoinjava.springbootsoapservice.service;

import com.example.howtodoinjava.springbootsoapservice.model.Students;
import com.howtodoinjava.xml.school.Student;

public interface StudentService {

	Students save(Students students);

	Students findByName(String name);

}
