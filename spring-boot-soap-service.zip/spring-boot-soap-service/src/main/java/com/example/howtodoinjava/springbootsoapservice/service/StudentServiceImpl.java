package com.example.howtodoinjava.springbootsoapservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.howtodoinjava.springbootsoapservice.model.Students;
import com.example.howtodoinjava.springbootsoapservice.repository.StudentsRepository;
import com.howtodoinjava.xml.school.Student;

@Service
public class StudentServiceImpl implements StudentService{
	@Autowired
	StudentsRepository studentRepository;
	@Override
	public Students save(Students students) {
		return studentRepository.save(students);
	}
	@Override
	public Students findByName(String name) {
		return studentRepository.findByName(name);
	}
	
}
